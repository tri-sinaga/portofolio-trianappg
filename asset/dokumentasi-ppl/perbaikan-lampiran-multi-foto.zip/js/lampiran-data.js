/* ==========================================================================
   DATA LAMPIRAN DOKUMENTASI KEGIATAN PPL DI SMAN 3 YOGYAKARTA
   ==========================================================================
   PANDUAN UPDATE FOTO OLEH PENGGUNA:
   1. Simpan file foto dokumentasi Anda ke folder: asset/dokumentasi-ppl/
   2. Pada item kegiatan yang sesuai, isi properti 'images' dengan beberapa jalur foto.
      Contoh: images: ["asset/dokumentasi-ppl/observasi-1.jpg", "asset/dokumentasi-ppl/observasi-2.jpg"]
   3. Jika 'image' bernilai kosong (""), galeri otomatis menampilkan placeholder
      visual yang rapi, profesional, dan siap pakai.
   4. Foto pertama menjadi thumbnail kartu; saat kartu dibuka, panah atau geser kiri/kanan untuk melihat foto lain.
   5. Properti 'image' lama tetap didukung, tetapi gunakan 'images' untuk beberapa foto per kegiatan.
   ========================================================================== */

const lampiranCategories = [
  { id: "ALL", label: "Semua" },
  { id: "OBSERVASI", label: "Observasi Pembelajaran" },
  { id: "PRAKTIK", label: "Praktik Mengajar" },
  { id: "PEMBELAJARAN", label: "Pelaksanaan Pembelajaran" },
  { id: "SEKOLAH", label: "Kegiatan Sekolah" },
  { id: "LAINNYA", label: "Lainnya" }
];

const lampiranData = [
  {
    id: "ppl-01",
    title: "Observasi Kelas X Informatika",
    category: "OBSERVASI",
    categoryLabel: "Observasi Pembelajaran",
    date: "12 Agustus 2025",
    location: "Ruang Kelas & Lab Komputer, SMAN 3 Yogyakarta",
    image: "", // Masukkan file foto ke asset/dokumentasi-ppl/ contoh: "asset/dokumentasi-ppl/observasi-kelas.jpg"
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Kegiatan observasi awal untuk mengenali karakteristik peserta didik, pola interaksi di kelas, dinamika belajar, dan kesiapan infrastruktur pembelajaran informatika di SMAN 3 Yogyakarta."
  },
  {
    id: "ppl-02",
    title: "Pelaksanaan Pembelajaran",
    category: "PEMBELAJARAN",
    categoryLabel: "Pelaksanaan Pembelajaran",
    date: "20 Agustus 2025",
    location: "Lab Komputer 1, SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Pelaksanaan pembelajaran materi berpikir komputasional dan algoritma dengan pendekatan berdiferensiasi konten dan proses, didukung fasilitas komputer sekolah."
  },
  {
    id: "ppl-03",
    title: "Kegiatan Upacara Bendera",
    category: "SEKOLAH",
    categoryLabel: "Kegiatan Sekolah",
    date: "17 Agustus 2025",
    location: "Lapangan Utama SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Partisipasi aktif mahasiswa PPL PPG Prajabatan dalam upacara peringatan Hari Ulang Tahun Republik Indonesia bersama seluruh dewan guru, staf, dan siswa Padmanaba."
  },
  {
    id: "ppl-04",
    title: "Diskusi Penyusunan Modul Ajar",
    category: "PRAKTIK",
    categoryLabel: "Praktik Mengajar",
    date: "25 Agustus 2025",
    location: "Ruang Guru Informatika, SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Sesi diskusi dan bimbingan bersama Guru Pamong dalam menyusun perangkat ajar berbasis Understanding by Design (UbD) serta instrumen asesmen diagnostik."
  },
  {
    id: "ppl-05",
    title: "Kegiatan Kebersihan Lingkungan Sekolah",
    category: "SEKOLAH",
    categoryLabel: "Kegiatan Sekolah",
    date: "29 Agustus 2025",
    location: "Lingkungan Kampus SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Keterlibatan dalam kegiatan jumat bersih dan pembiasaan budaya peduli lingkungan hidup bersama warga sekolah SMAN 3 Yogyakarta."
  },
  {
    id: "ppl-06",
    title: "Dokumentasi Lainnya",
    category: "LAINNYA",
    categoryLabel: "Lainnya",
    date: "5 September 2025",
    location: "SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Dokumentasi kebersamaan, koordinasi tim PPL, serta refleksi berkala sesama mahasiswa PPG Prajabatan bimbingan LPTK UNY di sekolah mitra."
  },
  {
    id: "ppl-07",
    title: "Praktik Mengajar Terbimbing Siklus 1",
    category: "PRAKTIK",
    categoryLabel: "Praktik Mengajar",
    date: "10 September 2025",
    location: "Ruang Kelas X-E SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Praktik mengajar terbimbing dengan pengawasan langsung dari Guru Pamong, mengintegrasikan media presentasi interaktif dan lembar kerja peserta didik kolaboratif."
  },
  {
    id: "ppl-08",
    title: "Observasi Sarana & Prasarana Lab Komputer",
    category: "OBSERVASI",
    categoryLabel: "Observasi Pembelajaran",
    date: "14 Agustus 2025",
    location: "Laboratorium Komputer Informatika",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Pemeriksaan kesiapan perangkat keras, jaringan LAN/internet, dan sistem operasi pendukung praktikum pemrograman peserta didik di laboratorium sekolah."
  },
  {
    id: "ppl-09",
    title: "Asesmen Formatif & Presentasi Kelompok Siswa",
    category: "PEMBELAJARAN",
    categoryLabel: "Pelaksanaan Pembelajaran",
    date: "24 September 2025",
    location: "Ruang Kelas X SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Sesi presentasi hasil proyek kelompok dan pelaksanaan asesmen formatif digital guna mengukur pemahaman peserta didik secara berkelanjutan."
  },
  {
    id: "ppl-10",
    title: "Partisipasi Kegiatan Literasi & Komunitas Sekolah",
    category: "SEKOLAH",
    categoryLabel: "Kegiatan Sekolah",
    date: "3 Oktober 2025",
    location: "Perpustakaan & Selasar SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Pendampingan kegiatan literasi pagi siswa dan keikutsertaan dalam kegiatan apresiasi bakat minat peserta didik di lingkungan SMAN 3 Yogyakarta."
  },
  {
    id: "ppl-11",
    title: "Praktik Mengajar Mandiri Siklus 2",
    category: "PRAKTIK",
    categoryLabel: "Praktik Mengajar",
    date: "15 Oktober 2025",
    location: "Kelas X SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Pelaksanaan pembelajaran secara mandiri dengan menerapkan model Problem-Based Learning (PBL) dan pengelolaan kelas berbasis Social Emotional Learning (SEL)."
  },
  {
    id: "ppl-12",
    title: "Bimbingan & Refleksi Bersama DPL dan Guru Pamong",
    category: "LAINNYA",
    categoryLabel: "Lainnya",
    date: "22 Oktober 2025",
    location: "Ruang Pertemuan SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Sesi monitoring, evaluasi berkala, dan refleksi pedagogik bersama Dosen Pembimbing Lapangan (DPL) serta Guru Pamong SMAN 3 Yogyakarta."
  },
  {
    id: "ppl-13",
    title: "Observasi Gaya Belajar dan Profil Peserta Didik",
    category: "OBSERVASI",
    categoryLabel: "Observasi Pembelajaran",
    date: "18 Agustus 2025",
    location: "Ruang Kelas X Informatika",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Penyebaran angket asesmen non-kognitif awal untuk memetakan modalitas belajar (visual, auditori, kinestetik) dan latar belakang kesiapan belajar siswa."
  },
  {
    id: "ppl-14",
    title: "Penerapan Model Pembelajaran Berbasis Masalah",
    category: "PRAKTIK",
    categoryLabel: "Praktik Mengajar",
    date: "28 Oktober 2025",
    location: "Lab Komputer SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Peserta didik mengidentifikasi kasus nyata di lingkungan sekitar dan merumuskan solusi berbasis komputasi secara berkelompok terstruktur."
  },
  {
    id: "ppl-15",
    title: "Penarikan & Penutupan PPL di SMAN 3 Yogyakarta",
    category: "SEKOLAH",
    categoryLabel: "Kegiatan Sekolah",
    date: "10 November 2025",
    location: "Aula Pertemuan SMAN 3 Yogyakarta",
    image: "",
    images: [], // Tambahkan beberapa foto di sini, contoh: ["asset/dokumentasi-ppl/foto-1.jpg", "asset/dokumentasi-ppl/foto-2.jpg"]
    description: "Acara resmi pelepasan dan penarikan mahasiswa PPL PPG Prajabatan bersama Kepala Sekolah, Wakil Kepala Sekolah, Guru Pamong, dan DPL."
  }
];
