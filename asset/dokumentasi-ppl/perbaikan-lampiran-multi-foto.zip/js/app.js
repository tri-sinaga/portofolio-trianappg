/* ==========================================================================
   PPG PRAJABATAN E-PORTFOLIO APPLICATION LOGIC
   ========================================================================== */

document.addEventListener('DOMContentLoaded', () => {
  initScrollProgress();
  initNavigation();
  initTimelines();
  initOverallJourney();
  initProjectsGrid();
  initDocumentRepository();
  initModals();
  initScrollReveal();
  initContactForm();
  initLampiranGallery();
});

/* --------------------------------------------------------------------------
   01. SCROLL PROGRESS INDICATOR & BACK TO TOP
   -------------------------------------------------------------------------- */
function initScrollProgress() {
  const progressBar = document.getElementById('scrollProgressBar');
  const backToTopBtn = document.getElementById('backToTopBtn');

  window.addEventListener('scroll', () => {
    const scrollTop = window.scrollY;
    const docHeight = document.documentElement.scrollHeight - window.innerHeight;
    const scrollPercent = (scrollTop / docHeight) * 100;

    if (progressBar) {
      progressBar.style.width = `${scrollPercent}%`;
    }

    if (backToTopBtn) {
      if (scrollTop > 400) {
        backToTopBtn.classList.add('visible');
      } else {
        backToTopBtn.classList.remove('visible');
      }
    }
  });

  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }
}

/* --------------------------------------------------------------------------
   02. NAVIGATION & ACTIVE SECTION OBSERVER
   -------------------------------------------------------------------------- */
function initNavigation() {
  const navbar = document.getElementById('navbar');
  const mobileToggle = document.getElementById('mobileMenuBtn');
  const mobileDrawer = document.getElementById('mobileDrawer');
  const navLinks = document.querySelectorAll('.nav-link');
  const sections = document.querySelectorAll('section[id]');

  // Sticky navbar shadow on scroll
  window.addEventListener('scroll', () => {
    if (window.scrollY > 20) {
      navbar.classList.add('scrolled');
    } else {
      navbar.classList.remove('scrolled');
    }
  });

  // Mobile menu toggle
  if (mobileToggle && mobileDrawer) {
    mobileToggle.addEventListener('click', () => {
      mobileDrawer.classList.toggle('open');
      const isOpen = mobileDrawer.classList.contains('open');
      mobileToggle.setAttribute('aria-expanded', isOpen);
    });

    // Close drawer when link clicked
    mobileDrawer.querySelectorAll('.nav-link').forEach(link => {
      link.addEventListener('click', () => {
        mobileDrawer.classList.remove('open');
        mobileToggle.setAttribute('aria-expanded', 'false');
      });
    });
  }

  // Active section observer
  const observerOptions = {
    root: null,
    rootMargin: '-20% 0px -60% 0px',
    threshold: 0
  };

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const activeId = entry.target.getAttribute('id');
        navLinks.forEach(link => {
          if (link.getAttribute('href') === `#${activeId}`) {
            link.classList.add('active');
          } else {
            link.classList.remove('active');
          }
        });
      }
    });
  }, observerOptions);

  sections.forEach(section => observer.observe(section));
}

/* --------------------------------------------------------------------------
   03. TIMELINE & REFLECTIONS (SEMESTER 1 & SEMESTER 2)
   -------------------------------------------------------------------------- */
function initTimelines() {
  renderSemesterTimeline('semester1Container', reflectionsData.semester1);
  renderSemesterTimeline('semester2Container', reflectionsData.semester2);
}

function renderSemesterTimeline(containerId, courses) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = courses.map((course, index) => `
    <div class="timeline-item reveal-on-scroll">
      <div class="timeline-marker"></div>
      <div class="reflection-card">
        <div class="reflection-card-header">
          <div>
            <div class="course-meta">
              <span class="course-code">${course.code}</span>
              <span class="badge badge-gold">Capaian Reflektif</span>
            </div>
            <h3 class="course-title">${course.title}</h3>
          </div>
        </div>

        <p class="lead-text" style="font-size: 0.95rem; margin-bottom: 1rem;">${course.summary}</p>

       

        <div class="reflection-actions">
          <a href="${course.driveUrl || 'https://drive.google.com/'}" target="_blank" rel="noopener noreferrer" class="btn btn-gold" style="text-decoration: none; display: inline-flex; align-items: center; gap: 0.5rem;">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
            View Reflection ↗
          </a>
        </div>
      </div>
    </div>
  `).join('');

  // Attach click events for modal triggers
  container.querySelectorAll('.btn-read-reflection').forEach(btn => {
    btn.addEventListener('click', () => {
      const courseId = btn.dataset.courseId;
      openReflectionModal(courseId);
    });
  });
}

/* --------------------------------------------------------------------------
   04. OVERALL JOURNEY STEPPER
   -------------------------------------------------------------------------- */
function initOverallJourney() {
  const steps = [
    { title: "Awal PPG", desc: "Komitmen Mengabdi" },
    { title: "Mengenal Diri", desc: "Refleksi Jatidiri" },
    { title: "Memahami Peserta Didik", desc: "Asesmen Diagnostik" },
    { title: "Memahami Pedagogi", desc: "UbD & Diferensiasi" },
    { title: "Praktik Mengajar", desc: "PPL Terbimbing & Mandiri" },
    { title: "Refleksi", desc: "Evaluasi Ketercapaian" },
    { title: "Inovasi", desc: "Desain Media & Action" },
    { title: "Guru Profesional", desc: "Pendidik Transformatif" }
  ];

  const stepperContainer = document.getElementById('journeyStepper');
  if (stepperContainer) {
    stepperContainer.innerHTML = steps.map((s, idx) => `
      <div class="journey-step">
        <div class="journey-node">${idx + 1}</div>
        <div class="journey-label">${s.title}<br><span style="font-size: 0.7rem; color: var(--color-text-secondary); font-weight: normal;">${s.desc}</span></div>
      </div>
    `).join('');
  }
}

/* --------------------------------------------------------------------------
   05. PROJECTS GRID & MODAL
   -------------------------------------------------------------------------- */
function initProjectsGrid() {
  const container = document.getElementById('projectsGrid');
  if (!container) return;

  container.innerHTML = projectsData.map(proj => `
    <div class="project-card reveal-on-scroll">
      <div class="project-thumb-container">
        <div class="project-thumb-icon">💡</div>
        <span class="project-badge-tag">${proj.tag}</span>
      </div>
      <div class="project-card-body">
        <h3 class="project-title">${proj.title}</h3>
        <div class="project-detail-row">
          <strong>Permasalahan:</strong> ${proj.problem}
        </div>
        <div class="project-detail-row">
          <strong>Solusi Inovatif:</strong> ${proj.solution}
        </div>
        <div class="project-detail-row" style="margin-top: 0.5rem;">
          <span class="badge badge-primary">${proj.techUsed}</span>
        </div>
        <div class="project-card-footer">
          <button class="btn btn-primary btn-sm btn-view-project" data-proj-id="${proj.id}" style="width: 100%;">
            View Project Details
          </button>
        </div>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('.btn-view-project').forEach(btn => {
    btn.addEventListener('click', () => {
      openProjectModal(btn.dataset.projId);
    });
  });
}

/* --------------------------------------------------------------------------
   06. DOCUMENT REPOSITORY & FILTERS
   -------------------------------------------------------------------------- */
function initDocumentRepository() {
  const container = document.getElementById('docGrid');
  const filterBtns = document.querySelectorAll('.filter-btn');
  if (!container) return;

  function renderDocs(category = 'ALL') {
    const filtered = category === 'ALL'
      ? documentsData
      : documentsData.filter(d => d.category === category);

    container.innerHTML = filtered.map(doc => `
      <div class="doc-card reveal-on-scroll">
        <div class="doc-icon-header">
          <div class="doc-icon">${doc.icon}</div>
          <span class="badge badge-gold">${doc.categoryLabel}</span>
        </div>
        <h4 class="doc-title">${doc.title}</h4>
        <p class="doc-desc">${doc.description}</p>
        <div style="font-size: 0.75rem; color: var(--color-text-secondary); margin-bottom: 1rem;">
          📅 ${doc.date} &nbsp;•&nbsp; 📁 ${doc.fileType}
        </div>
        <div class="doc-actions">
          <button class="btn btn-secondary btn-sm btn-view-doc" data-doc-id="${doc.id}" style="flex: 1;">
            Preview
          </button>
          <a href="${doc.driveUrl || 'https://drive.google.com/'}" target="_blank" rel="noopener noreferrer" class="btn btn-primary btn-sm" style="display: inline-flex; align-items: center; gap: 0.25rem; text-decoration: none;">
            Google Drive ↗
          </a>
        </div>
      </div>
    `).join('');

    container.querySelectorAll('.btn-view-doc').forEach(btn => {
      btn.addEventListener('click', () => openDocViewerModal(btn.dataset.docId));
    });
  }

  renderDocs('ALL');

  filterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      filterBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      renderDocs(btn.dataset.filter);
    });
  });
}

/* --------------------------------------------------------------------------
   07. MODAL UTILITIES & CONTENT GENERATOR
   -------------------------------------------------------------------------- */
function initModals() {
  const modalOverlay = document.getElementById('modalOverlay');
  const modalClose = document.getElementById('modalCloseBtn');

  if (modalClose && modalOverlay) {
    modalClose.addEventListener('click', closeModal);
    modalOverlay.addEventListener('click', (e) => {
      if (e.target === modalOverlay) closeModal();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && modalOverlay.classList.contains('open')) {
        closeModal();
      }
    });
  }
}

function openModal(title, contentHtml, footerHtml = '') {
  const modalOverlay = document.getElementById('modalOverlay');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');
  const modalFooter = document.getElementById('modalFooter');

  if (!modalOverlay) return;

  if (modalTitle) modalTitle.textContent = title;
  if (modalBody) modalBody.innerHTML = contentHtml;
  if (modalFooter) modalFooter.innerHTML = footerHtml;

  modalOverlay.classList.add('open');
  modalOverlay.setAttribute('aria-hidden', 'false');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  const modalOverlay = document.getElementById('modalOverlay');
  if (modalOverlay) {
    modalOverlay.classList.remove('open');
    modalOverlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }
}

/* Modal Content Generators */
function openReflectionModal(courseId) {
  const allCourses = [...reflectionsData.semester1, ...reflectionsData.semester2];
  const course = allCourses.find(c => c.id === courseId);
  if (!course) return;

  const html = `
    <div style="margin-bottom: 1.5rem;">
      <span class="badge badge-primary">${course.code}</span>
      <h3 style="margin-top: 0.5rem; color: var(--color-dark);">${course.title}</h3>
      <p class="lead-text">${course.summary}</p>
    </div>

    
    <div style="display: flex; flex-direction: column; gap: 1.25rem;">
     <div style="background: var(--color-gold-light); padding: 1.25rem; border: 1px solid var(--color-gold); border-radius: 6px;">
        <h4 style="color: var(--color-dark); margin-bottom: 0.4rem;">📎 Artefak Bukti Belajar</h4>
        <p><strong>${course.artifactTitle}</strong> (${course.artifactType})</p>
        <p style="font-size: 0.9rem; color: var(--color-text-secondary); margin-top: 0.5rem; line-height: 1.6;">${course.framework.artefak}</p>
      </div>
    </div>
    
  `;

  const footer = `
    <a href="${course.driveUrl || 'https://drive.google.com/'}" target="_blank" rel="noopener noreferrer" class="btn btn-gold" style="text-decoration: none; display: inline-flex; align-items: center; gap: 0.35rem;">View Related Artifact ↗</a>
    <button class="btn btn-secondary" onclick="closeModal()">Close</button>
  `;

  openModal(`Analisis Reflektif — ${course.title}`, html, footer);
}

function openArtifactModal(courseId) {
  const allCourses = [...reflectionsData.semester1, ...reflectionsData.semester2];
  const course = allCourses.find(c => c.id === courseId);
  if (!course) return;

  const driveUrl = course.driveUrl || "https://drive.google.com/";
  window.open(driveUrl, '_blank');
}

function openProjectModal(projId) {
  const proj = projectsData.find(p => p.id === projId);
  if (!proj) return;

  const html = `
    <div style="margin-bottom: 1.5rem;">
      <span class="badge badge-gold">${proj.tag}</span>
      <h3 style="margin-top: 0.5rem; color: var(--color-dark);">${proj.title}</h3>
      <p class="lead-text">${proj.details}</p>
    </div>

    <div style="display: flex; flex-direction: column; gap: 1.25rem;">
      <div style="background: #FFF5F5; border-left: 4px solid #E53E3E; padding: 1.25rem; border-radius: 6px;">
        <h4 style="color: #9B2C2C; margin-bottom: 0.4rem;">⚠️ Permasalahan Pembelajaran</h4>
        <p>${proj.problem}</p>
      </div>

      <div style="background: #F0FFF4; border-left: 4px solid var(--color-green); padding: 1.25rem; border-radius: 6px;">
        <h4 style="color: var(--color-green); margin-bottom: 0.4rem;">💡 Solusi & Kebaharuan (Inovasi)</h4>
        <p>${proj.solution}</p>
        <p style="margin-top: 0.5rem; font-size: 0.9rem;"><strong>Elemen Inovatif:</strong> ${proj.innovation}</p>
      </div>

      <div style="background: var(--color-primary-light); padding: 1.25rem; border-radius: 6px;">
        <h4 style="color: var(--color-primary); margin-bottom: 0.4rem;">🛠️ Teknologi & Tools Digunakan</h4>
        <p style="font-weight: 600;">${proj.techUsed}</p>
      </div>

      <div style="background: var(--color-gold-light); padding: 1.25rem; border-radius: 6px;">
        <h4 style="color: var(--color-dark); margin-bottom: 0.4rem;">📈 Impact / Dampak Terukur</h4>
        <p>${proj.impact}</p>
      </div>
    </div>
  `;

  const footer = `
    <button class="btn btn-primary" onclick="alert('Membuka dokumentasi lengkap proyek inovasi...')">View Full Documentation</button>
    <button class="btn btn-secondary" onclick="closeModal()">Close</button>
  `;

  openModal(`Karya Inovasi — ${proj.title}`, html, footer);
}

function openDocViewerModal(docId) {
  const doc = documentsData.find(d => d.id === docId);
  if (!doc) return;

  const driveUrl = doc.driveUrl || "https://drive.google.com/";

  const html = `
    <div class="doc-viewer-sim">
      <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 0.5rem;">
        <span class="badge badge-gold">${doc.categoryLabel}</span>
        <span class="badge badge-primary" style="background: #E8F0FE; color: #1A73E8; border: 1px solid #C2E7FF;">Google Drive Storage</span>
      </div>
      <h3 style="margin-top: 0.5rem; color: var(--color-dark);">${doc.title}</h3>
      <p class="caption-text">Tanggal: ${doc.date} | Format: ${doc.fileType}</p>

      <div class="doc-sheet-paper" style="margin-top: 1.5rem;">
        <h4 style="border-bottom: 2px solid var(--color-gold); padding-bottom: 0.5rem; margin-bottom: 1rem; color: var(--color-primary);">
          PREVIEW DOKUMEN REPOSITORI AKADEMIK
        </h4>
        <pre style="white-space: pre-wrap; font-family: var(--font-body); font-size: 0.9rem; color: var(--color-text-primary); line-height: 1.6;">${doc.contentSnippet}</pre>
        
        <div style="margin-top: 2rem; padding-top: 1rem; border-top: 1px solid var(--color-border); font-size: 0.8rem; color: var(--color-text-secondary);">
          * Dokumen ini terverifikasi secara legal sebagai hasil karya portofolio akademik PPG Prajabatan yang tersimpan di Google Drive.
        </div>
      </div>
    </div>
  `;

  const footer = `
    <a href="${driveUrl}" target="_blank" rel="noopener noreferrer" class="btn btn-primary" style="display: inline-flex; align-items: center; gap: 0.5rem; text-decoration: none;">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
      Buka Berkas di Google Drive
    </a>
    <button class="btn btn-secondary" onclick="closeModal()">Tutup</button>
  `;

  openModal(`Document Viewer — ${doc.title}`, html, footer);
}

function triggerDownloadSimulation(id) {
  const allCourses = [...reflectionsData.semester1, ...reflectionsData.semester2];
  const course = allCourses.find(c => c.id === id);
  const doc = documentsData.find(d => d.id === id);
  const targetUrl = (course && course.driveUrl) || (doc && doc.driveUrl) || "https://drive.google.com/";

  window.open(targetUrl, '_blank');
}

window.openSummaryModal = function () {
  const html = `
    <div style="text-align: center; padding: 1rem 0;">
      <img src="asset/IMG_4645.JPG" alt="Foto Profil Mahasiswa" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; object-position: center top; margin: 0 auto 1rem auto; border: 2px solid var(--color-gold); display: block;">
      <h3 style="color: var(--color-dark);">PORTOFOLIO AKADEMIK PPG PRAJABATAN</h3>
      <p style="font-weight: 600; color: var(--color-primary);">[NAMA LENGKAP] | NIM: [NIM]</p>
      <p class="caption-text">Program Studi: [PROGRAM STUDI] | Lokasi PPL: [LOKASI PPL]</p>
    </div>

    <div style="background: var(--color-bg); padding: 1.5rem; border-radius: 8px; margin-top: 1rem;">
      <h4 style="color: var(--color-dark); margin-bottom: 0.75rem;">Ringkasan Capaian Portofolio:</h4>
      <ul style="padding-left: 1.25rem; font-size: 0.925rem; line-height: 1.8;">
        <li><strong>Total Mata Kuliah Direfleksikan:</strong> 11 Mata Kuliah (Semester 1 & 2)</li>
        <li><strong>Kerangka Refleksi:</strong> Refleksi Akademik & Artefak Bukti Belajar</li>
        <li><strong>Karya Inovasi Utama:</strong> Media AR GeoNusantara, Modul UbD, App Asesmen</li>
        <li><strong>Projek Kepemimpinan:</strong> Pojok Baca & Literasi Inklusif Komunitas</li>
        <li><strong>Status Penilaian LPTK:</strong> Lengkap & Terverifikasi (2026)</li>
      </ul>
    </div>
  `;

  const footer = `
    <button class="btn btn-primary" onclick="alert('Mengunduh Ringkasan Cetak Portofolio PDF...')">Download Summary PDF</button>
    <button class="btn btn-secondary" onclick="closeModal()">Close</button>
  `;

  openModal('Ringkasan Portofolio Akademik PPG', html, footer);
};

/* --------------------------------------------------------------------------
   08. SCROLL REVEAL ANIMATIONS
   -------------------------------------------------------------------------- */
function initScrollReveal() {
  const elements = document.querySelectorAll('.reveal-on-scroll');

  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
      }
    });
  }, { threshold: 0.1 });

  elements.forEach(el => observer.observe(el));
}

/* --------------------------------------------------------------------------
   09. CONTACT FORM HANDLER
   -------------------------------------------------------------------------- */
function initContactForm() {
  const form = document.getElementById('contactForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      alert('Terima kasih! Pesan dan undangan kolaborasi Anda telah berhasil terkirim.');
      form.reset();
    });
  }
}

window.handleLampiranImgError = function(img, categoryLabel, isLightbox = false) {
  if (!img || !img.parentElement) return;
  const parent = img.parentElement;
  if (isLightbox) {
    parent.innerHTML = `
      <div class="lampiran-lightbox-placeholder">
        <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
          <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
          <circle cx="12" cy="13" r="4"></circle>
        </svg>
        <h3>Foto Dokumentasi PPL</h3>
        <p>File foto belum ditemukan di folder <code>asset/dokumentasi-ppl/</code>. Pastikan file foto sudah diletakkan di folder tersebut dan namanya sesuai dengan konfigurasi di <code>js/lampiran-data.js</code>.</p>
      </div>
    `;
  } else {
    parent.innerHTML = `
      <span class="lampiran-category-badge">${categoryLabel}</span>
      <div class="lampiran-placeholder">
        <div class="lampiran-placeholder-icon-wrap">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
            <circle cx="12" cy="13" r="4"></circle>
          </svg>
        </div>
        <div class="lampiran-placeholder-title">Dokumentasi PPL</div>
        <span class="lampiran-placeholder-tag">[Siap Ditambahkan Foto]</span>
      </div>
      <div class="lampiran-thumb-overlay">
        <span class="lampiran-overlay-btn">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          Perbesar Foto
        </span>
      </div>
    `;
  }
};

/* --------------------------------------------------------------------------
   10. LAMPIRAN DOKUMENTASI PPL (SMAN 3 YOGYAKARTA)
   -------------------------------------------------------------------------- */
function initLampiranGallery() {
  const filterBar = document.getElementById('lampiranFilterBar');
  const gridContainer = document.getElementById('lampiranGrid');
  const paginationWrapper = document.getElementById('lampiranPagination');
  const lightboxOverlay = document.getElementById('lampiranLightbox');

  if (!gridContainer || typeof lampiranData === 'undefined') return;

  let currentCategory = 'ALL';
  let currentPage = 1;
  const itemsPerPage = 6;
  let activeItems = [...lampiranData];
  let currentLightboxIndex = 0;
  let currentLightboxPhotoIndex = 0;

  // Mendukung beberapa foto pada satu kegiatan melalui properti images: [].
  // Properti image lama tetap didukung agar data sebelumnya tidak rusak.
  function getItemImages(item) {
    if (Array.isArray(item.images)) {
      const validImages = item.images.filter(src => typeof src === 'string' && src.trim() !== '');
      if (validImages.length) return validImages;
    }
    return item.image && item.image.trim() !== '' ? [item.image] : [];
  }

  function changeLightboxPhoto(step) {
    const item = activeItems[currentLightboxIndex];
    if (!item) return;
    const images = getItemImages(item);
    if (images.length <= 1) return;
    currentLightboxPhotoIndex = (currentLightboxPhotoIndex + step + images.length) % images.length;
    updateLightboxContent();
  }

  function getPlaceholderHtml(categoryLabel, isLightbox = false) {
    if (isLightbox) {
      return `
        <div class="lampiran-lightbox-placeholder">
          <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
            <circle cx="12" cy="13" r="4"></circle>
          </svg>
          <h3>Foto Dokumentasi PPL</h3>
          <p>Area dokumentasi kegiatan di SMA Negeri 3 Yogyakarta. Untuk menampilkan foto asli, simpan file foto pada folder <code>asset/dokumentasi-ppl/</code> dan perbarui jalur foto di <code>js/lampiran-data.js</code>.</p>
        </div>
      `;
    }

    return `
      <div class="lampiran-placeholder">
        <div class="lampiran-placeholder-icon-wrap">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
            <circle cx="12" cy="13" r="4"></circle>
          </svg>
        </div>
        <div class="lampiran-placeholder-title">Dokumentasi PPL</div>
        <span class="lampiran-placeholder-tag">[Siap Ditambahkan Foto]</span>
      </div>
    `;
  }

  // Render Filter Buttons
  if (filterBar && typeof lampiranCategories !== 'undefined') {
    filterBar.innerHTML = lampiranCategories.map(cat => `
      <button class="lampiran-filter-btn ${cat.id === 'ALL' ? 'active' : ''}" data-cat-id="${cat.id}">
        ${cat.label}
      </button>
    `).join('');

    filterBar.querySelectorAll('.lampiran-filter-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        filterBar.querySelectorAll('.lampiran-filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentCategory = btn.dataset.catId;
        currentPage = 1;
        updateGallery();
      });
    });
  }

  function updateGallery() {
    activeItems = currentCategory === 'ALL'
      ? lampiranData
      : lampiranData.filter(item => item.category === currentCategory);

    const totalItems = activeItems.length;
    const totalPages = Math.ceil(totalItems / itemsPerPage) || 1;
    if (currentPage > totalPages) currentPage = totalPages;

    const startIndex = (currentPage - 1) * itemsPerPage;
    const pageItems = activeItems.slice(startIndex, startIndex + itemsPerPage);

    if (pageItems.length === 0) {
      gridContainer.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 3.5rem 1rem; color: var(--color-text-secondary); background: #FFFFFF; border-radius: var(--radius-md); border: 1px dashed var(--color-border);">
          <div style="font-size: 2.5rem; margin-bottom: 0.5rem;">📂</div>
          <p style="font-size: 1rem; font-weight: 500;">Belum ada dokumentasi untuk kategori ini.</p>
        </div>
      `;
    } else {
      gridContainer.innerHTML = pageItems.map((item, index) => {
        const itemGlobalIndex = startIndex + index;
        const itemImages = getItemImages(item);
        const hasValidImage = itemImages.length > 0;
        const thumbnailImage = itemImages[0];

        return `
          <div class="lampiran-card reveal-on-scroll is-visible" data-index="${itemGlobalIndex}" tabindex="0" role="button" aria-label="${item.title}">
            <div class="lampiran-thumb-wrap">
              <span class="lampiran-category-badge">${item.categoryLabel}</span>
              ${hasValidImage ? `
                <img src="${thumbnailImage}" alt="${item.title}" class="lampiran-thumb-img" onerror="handleLampiranImgError(this, '${item.categoryLabel}', false);">
              ` : getPlaceholderHtml(item.categoryLabel)}
              ${itemImages.length > 1 ? `<span class="lampiran-photo-count">📷 ${itemImages.length} foto</span>` : ''}
              <div class="lampiran-thumb-overlay">
                <span class="lampiran-overlay-btn">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line><line x1="11" y1="8" x2="11" y2="14"></line><line x1="8" y1="11" x2="14" y2="11"></line></svg>
                  Perbesar Foto
                </span>
              </div>
            </div>

            <div class="lampiran-card-body">
              <h3 class="lampiran-card-title">${item.title}</h3>
              <div class="lampiran-card-date">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                ${item.date}
              </div>
              <p class="lampiran-card-desc">${item.description}</p>
              <div class="lampiran-card-footer">
                <span>📍 ${item.location || 'SMAN 3 Yogyakarta'}</span>
                <span>Detail ↗</span>
              </div>
            </div>
          </div>
        `;
      }).join('');

      // Attach click and keyboard events for cards to open lightbox
      gridContainer.querySelectorAll('.lampiran-card').forEach(card => {
        card.addEventListener('click', () => {
          const index = parseInt(card.dataset.index, 10);
          openLightbox(index);
        });
        card.addEventListener('keydown', (e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            const index = parseInt(card.dataset.index, 10);
            openLightbox(index);
          }
        });
      });
    }

    renderPagination(totalPages);
  }

  function renderPagination(totalPages) {
    if (!paginationWrapper) return;

    if (totalPages <= 1) {
      paginationWrapper.innerHTML = '';
      return;
    }

    let buttonsHtml = `
      <div class="lampiran-pagination">
        <button class="pagination-btn" id="lampiranPrevPageBtn" ${currentPage === 1 ? 'disabled' : ''} aria-label="Halaman Sebelumnya">
          &lsaquo;
        </button>
    `;

    for (let p = 1; p <= totalPages; p++) {
      buttonsHtml += `
        <button class="pagination-btn ${p === currentPage ? 'active' : ''}" data-page="${p}">
          ${p}
        </button>
      `;
    }

    buttonsHtml += `
        <button class="pagination-btn" id="lampiranNextPageBtn" ${currentPage === totalPages ? 'disabled' : ''} aria-label="Halaman Berikutnya">
          &rsaquo;
        </button>
      </div>
    `;

    paginationWrapper.innerHTML = buttonsHtml;

    paginationWrapper.querySelectorAll('.pagination-btn[data-page]').forEach(btn => {
      btn.addEventListener('click', () => {
        currentPage = parseInt(btn.dataset.page, 10);
        updateGallery();
        const lampiranSection = document.getElementById('lampiran');
        if (lampiranSection) {
          lampiranSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      });
    });

    const prevPageBtn = document.getElementById('lampiranPrevPageBtn');
    if (prevPageBtn) {
      prevPageBtn.addEventListener('click', () => {
        if (currentPage > 1) {
          currentPage--;
          updateGallery();
          const lampiranSection = document.getElementById('lampiran');
          if (lampiranSection) {
            lampiranSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }
      });
    }

    const nextPageBtn = document.getElementById('lampiranNextPageBtn');
    if (nextPageBtn) {
      nextPageBtn.addEventListener('click', () => {
        if (currentPage < totalPages) {
          currentPage++;
          updateGallery();
          const lampiranSection = document.getElementById('lampiran');
          if (lampiranSection) {
            lampiranSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        }
      });
    }
  }

  // Lightbox Implementation
  const lightboxCategory = document.getElementById('lightboxCategory');
  const lightboxCounter = document.getElementById('lightboxCounter');
  const lightboxMediaContainer = document.getElementById('lightboxMediaContainer');
  const lightboxTitle = document.getElementById('lightboxTitle');
  const lightboxDate = document.getElementById('lightboxDate');
  const lightboxLocation = document.getElementById('lightboxLocation');
  const lightboxDesc = document.getElementById('lightboxDesc');
  const lightboxCloseBtn = document.getElementById('lightboxCloseBtn');
  const lightboxPrevBtn = document.getElementById('lightboxPrevBtn');
  const lightboxNextBtn = document.getElementById('lightboxNextBtn');

  function openLightbox(index) {
    if (!lightboxOverlay || activeItems.length === 0) return;
    currentLightboxIndex = index;
    currentLightboxPhotoIndex = 0;
    updateLightboxContent();
    lightboxOverlay.classList.add('open');
    lightboxOverlay.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closeLightbox() {
    if (!lightboxOverlay) return;
    lightboxOverlay.classList.remove('open');
    lightboxOverlay.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
  }

  function updateLightboxContent() {
    if (currentLightboxIndex < 0) currentLightboxIndex = activeItems.length - 1;
    if (currentLightboxIndex >= activeItems.length) currentLightboxIndex = 0;

    const item = activeItems[currentLightboxIndex];
    if (!item) return;

    const images = getItemImages(item);
    if (currentLightboxPhotoIndex >= images.length) currentLightboxPhotoIndex = 0;

    if (lightboxCategory) lightboxCategory.textContent = item.categoryLabel;
    if (lightboxCounter) lightboxCounter.textContent = images.length
      ? `Foto ${currentLightboxPhotoIndex + 1} dari ${images.length}`
      : 'Belum ada foto';
    if (lightboxTitle) lightboxTitle.textContent = item.title;
    if (lightboxDate) lightboxDate.textContent = `📅 ${item.date}`;
    if (lightboxLocation) lightboxLocation.textContent = `📍 ${item.location || 'SMAN 3 Yogyakarta'}`;
    if (lightboxDesc) lightboxDesc.textContent = item.description;

    // Panah hanya ditampilkan jika kegiatan memiliki lebih dari satu foto.
    const showPhotoNavigation = images.length > 1;
    if (lightboxPrevBtn) lightboxPrevBtn.style.display = showPhotoNavigation ? '' : 'none';
    if (lightboxNextBtn) lightboxNextBtn.style.display = showPhotoNavigation ? '' : 'none';

    if (lightboxMediaContainer) {
      if (images.length) {
        lightboxMediaContainer.innerHTML = `
          <img src="${images[currentLightboxPhotoIndex]}" alt="${item.title} - foto ${currentLightboxPhotoIndex + 1}" class="lampiran-lightbox-img" onerror="handleLampiranImgError(this, '${item.categoryLabel}', true);">
        `;
      } else {
        lightboxMediaContainer.innerHTML = getPlaceholderHtml(item.categoryLabel, true);
      }
    }
  }

  if (lightboxCloseBtn) {
    lightboxCloseBtn.addEventListener('click', closeLightbox);
  }

  if (lightboxOverlay) {
    lightboxOverlay.addEventListener('click', (e) => {
      if (e.target === lightboxOverlay) {
        closeLightbox();
      }
    });
  }

  if (lightboxPrevBtn) {
    lightboxPrevBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      changeLightboxPhoto(-1);
    });
  }

  if (lightboxNextBtn) {
    lightboxNextBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      changeLightboxPhoto(1);
    });
  }

  document.addEventListener('keydown', (e) => {
    if (lightboxOverlay && lightboxOverlay.classList.contains('open')) {
      if (e.key === 'Escape') {
        closeLightbox();
      } else if (e.key === 'ArrowLeft') {
        changeLightboxPhoto(-1);
      } else if (e.key === 'ArrowRight') {
        changeLightboxPhoto(1);
      }
    }
  });

  // Swipe kiri/kanan pada gambar untuk mengganti foto di perangkat sentuh.
  let touchStartX = null;
  if (lightboxMediaContainer) {
    lightboxMediaContainer.addEventListener('touchstart', (e) => {
      touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });
    lightboxMediaContainer.addEventListener('touchend', (e) => {
      if (touchStartX === null) return;
      const deltaX = e.changedTouches[0].screenX - touchStartX;
      if (Math.abs(deltaX) > 45) changeLightboxPhoto(deltaX < 0 ? 1 : -1);
      touchStartX = null;
    }, { passive: true });
  }

  // Initial render
  updateGallery();
}
